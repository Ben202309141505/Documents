/****** Object:  Table [dbo].[dim_Source_Customer]    Script Date: 6/16/2023 6:40:49 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dim_Source_Customer]
(
	[SourceCustomerKey] [int] NOT NULL,
	[MarketCode] [varchar](10) NOT NULL,
	[SourceCustomerID] [nvarchar](240) NULL,
	[SourceCustomer] [nvarchar](240) NOT NULL,
	[SourceCustomerLongName] [nvarchar](300) NOT NULL,
	[MasterCustomerID] [nvarchar](240) NULL,
	[SourceCustomerLevelID] [varchar](100) NOT NULL,
	[SourceCustomerLevel] [nvarchar](140) NOT NULL,
	[LevelID] [varchar](20) NOT NULL,
	[SalesOrganizationID] [nvarchar](10) NULL,
	[SourceSystem] [nvarchar](20) NULL,
	[SourceCustomerLevel2ID] [varchar](100) NOT NULL,
	[SourceCustomerLevel2] [nvarchar](140) NOT NULL,
	[CRMCustomerLevel2ID] [varchar](50) NOT NULL,
	[CRMCustomerLevel2] [nvarchar](150) NOT NULL,
	[Level2ID] [varchar](20) NOT NULL,
	[CRMBranchStatus] [nvarchar](12) NOT NULL,
	[SourceCustomerLevel1ID] [varchar](100) NOT NULL,
	[SourceCustomerLevel1] [nvarchar](140) NOT NULL,
	[CRMCustomerLevel1ID] [varchar](50) NOT NULL,
	[CRMCustomerLevel1] [nvarchar](140) NOT NULL,
	[Level1ID] [varchar](20) NOT NULL,
	[CRMHOStatus] [varchar](10) NOT NULL,
	[BuyingGroupID] [varchar](15) NOT NULL,
	[BuyingGroup] [nvarchar](140) NOT NULL,
	[InsertDate] [datetime2](7) NULL,
	[UpdateDate] [datetime2](7) NULL,
	[JobRunID] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


