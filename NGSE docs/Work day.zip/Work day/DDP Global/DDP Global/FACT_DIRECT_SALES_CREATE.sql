/****** Object:  Table [dbo].[fact_Direct_Sales]    Script Date: 6/16/2023 7:03:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fact_Direct_Sales]
(
	[dim_Date_Key] [int] NOT NULL,
	[dim_Product_Key] [int] NOT NULL,
	[dim_Sold_to_Customer_Key] [int] NOT NULL,
	[dim_Ship_to_Customer_Key] [int] NOT NULL,
	[dim_Bill_to_Customer_Key] [int] NOT NULL,
	[dim_Paid_by_Customer_Key] [int] NOT NULL,
	[dim_Sales_Organization_Key] [smallint] NOT NULL,
	[dim_Business_Area_Key] [smallint] NOT NULL,
	[dim_Profit_Center_Key] [int] NOT NULL,
	[dim_Unit_of_Measure_Key] [smallint] NOT NULL,
	[dim_List_Price_Unit_of_Measure_Key] [smallint] NOT NULL,
	[dim_Currency_Key] [smallint] NOT NULL,
	[dim_TP_Direct_Sales_Key] [int] NOT NULL,
	[Billing Document Number] [varchar](40) NOT NULL,
	[Billing Document Item Number] [varchar](10) NOT NULL,
	[Sales Document Number] [varchar](10) NOT NULL,
	[Sales Document Item] [varchar](10) NOT NULL,
	[Delivery Number] [varchar](10) NOT NULL,
	[Delivery Item Number] [varchar](10) NOT NULL,
	[Invoice Quantity] [decimal](16, 3) NOT NULL,
	[Invoice Quantity in Base UOM] [decimal](16, 3) NOT NULL,
	[Invoice Quantity in List Price UOM] [decimal](16, 3) NOT NULL,
	[Net Invoice Amount] [decimal](17, 2) NULL,
	[Gross Invoice Amount] [decimal](17, 2) NULL,
	[List Price] [decimal](16, 2) NULL,
	[List Price Adjustment and Discount] [decimal](16, 2) NULL,
	[Freight Cost] [decimal](16, 2) NULL,
	[Tax Amount] [decimal](16, 2) NULL,
	[Net Invoice Amount in USD] [decimal](17, 2) NULL,
	[Gross Invoice Amount in USD] [decimal](17, 2) NULL,
	[List Price in USD] [decimal](16, 2) NULL,
	[List Price Adjustment and Discount in USD] [decimal](16, 2) NULL,
	[Freight Cost in USD] [decimal](16, 2) NULL,
	[Tax Amount in USD] [decimal](16, 2) NULL,
	[Insert_Date] [datetime2](7) NULL,
	[Update_Date] [datetime2](7) NULL,
	[Job_Run_Key] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [Billing Document Number] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO


