/****** Object:  Table [dbo].[dim_TP_Account_Position]    Script Date: 6/16/2023 6:54:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dim_TP_Account_Position]
(
	[dimTPfactAccountPositionKey] [int] NOT NULL,
	[AccountType] [nvarchar](100) NOT NULL,
	[PositionFlag] [varchar](10) NOT NULL,
	[AcccountPositionFlag] [varchar](10) NOT NULL,
	[SalesExclusionFlag] [varchar](10) NOT NULL,
	[Deleted] [varchar](10) NOT NULL,
	[AccountPositionCustomFlag] [varchar](20) NOT NULL,
	[AcccountPositionActiveFlag] [varchar](20) NOT NULL,
	[InsertDate] [datetime] NULL,
	[UpateDate] [datetime] NULL,
	[JobRunID] [int] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


