/****** Object:  Table [dbo].[rpt_Currency_Conversion_Rate]    Script Date: 6/16/2023 7:02:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[rpt_Currency_Conversion_Rate]
(
	[Exchange Rate Type] [char](10) NOT NULL,
	[From Currency ID] [char](10) NOT NULL,
	[To Currency ID] [char](10) NOT NULL,
	[Exchange Rate Date] [date] NOT NULL,
	[Exchange Rate End of Month Date] [date] NOT NULL,
	[Exchange Rate] [decimal](13, 7) NOT NULL,
	[Decimal Multiplier for Local Currency] [decimal](6, 1) NOT NULL,
	[Insert_Date] [datetime2](7) NULL,
	[Update_Date] [datetime2](7) NULL,
	[Job_Run_Key] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


