/****** Object:  Table [dbo].[fact_Customer_Brand_Potential]    Script Date: 6/16/2023 6:59:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fact_Customer_Brand_Potential]
(
	[dimProductKey] [int] NOT NULL,
	[dimCustomerKey] [int] NOT NULL,
	[dimMarketCodeKey] [int] NOT NULL,
	[dimTPCustomerBrandPotentialKey] [int] NOT NULL,
	[BrandPotential] [decimal](17, 2) NULL,
	[CalculatedValueofPotential] [decimal](17, 2) NULL,
	[LoadedDate] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


