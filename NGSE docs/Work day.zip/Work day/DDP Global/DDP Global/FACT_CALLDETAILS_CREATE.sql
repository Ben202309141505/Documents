/****** Object:  Table [dbo].[fact_CallDetails]    Script Date: 6/16/2023 7:00:30 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fact_CallDetails]
(
	[dimActualStartDateKey] [int] NOT NULL,
	[dimActualEndDateKey] [int] NOT NULL,
	[dimEndDateKey] [int] NOT NULL,
	[dimCreatedDateKey] [int] NOT NULL,
	[dimSubmittedDateKey] [int] NOT NULL,
	[dimLastModifiedDateKey] [int] NOT NULL,
	[dimLastChangeDateKey] [int] NOT NULL,
	[dimProductKey] [int] NOT NULL,
	[dimCustomerKey] [int] NOT NULL,
	[dimTerritoryKey] [int] NOT NULL,
	[dimSalesRepresentativeKey] [int] NOT NULL,
	[dimMarketCodeKey] [int] NOT NULL,
	[dimTPCallDetailsKey] [int] NOT NULL,
	[UniqueCallNumber] [varchar](20) NOT NULL,
	[CallDuration] [varchar](15) NOT NULL,
	[CallCount] [decimal](17, 0) NOT NULL,
	[LoadedDate] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


