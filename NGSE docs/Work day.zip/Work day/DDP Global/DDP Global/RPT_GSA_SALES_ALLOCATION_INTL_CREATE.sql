/****** Object:  Table [dbo].[rpt_GSA_Sales_Allocation_INTL]    Script Date: 6/16/2023 6:49:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[rpt_GSA_Sales_Allocation_INTL]
(
	[Date] [varchar](10) NOT NULL,
	[ProductID] [varchar](70) NOT NULL,
	[SourceProductID] [varchar](100) NOT NULL,
	[CustomerID] [varchar](50) NOT NULL,
	[BillToShipToSourceCustomerID] [varchar](120) NOT NULL,
	[DistributorSourceCustomerID] [varchar](50) NOT NULL,
	[BillToSourceCustomerID] [varchar](50) NOT NULL,
	[ShipToSourceCustomerID] [varchar](120) NOT NULL,
	[CRMTerritoryUniqueID] [varchar](25) NOT NULL,
	[MarketCode] [varchar](10) NOT NULL,
	[SalesOrganizationID] [varchar](25) NOT NULL,
	[BusinessAreaID] [varchar](25) NOT NULL,
	[ProfitCenterID] [varchar](25) NOT NULL,
	[UnitofMeasureID] [varchar](25) NOT NULL,
	[CurrencyCode] [varchar](10) NOT NULL,
	[SourceSystem] [varchar](50) NOT NULL,
	[SaleType] [varchar](50) NOT NULL,
	[InvoiceTypeID] [varchar](25) NOT NULL,
	[InvoiceType] [varchar](25) NOT NULL,
	[SalesDocumentTypeID] [varchar](25) NOT NULL,
	[SalesDocumentType] [nvarchar](25) NOT NULL,
	[SalesDocumentItemCategoryID] [varchar](25) NOT NULL,
	[SalesDocumentItemCategory] [nvarchar](25) NOT NULL,
	[BillingDocumentNumber] [varchar](25) NOT NULL,
	[BillingDocumentItemNumber] [varchar](25) NOT NULL,
	[SalesDocumentNumber] [varchar](25) NOT NULL,
	[SalesDocumentItem] [varchar](25) NOT NULL,
	[InvoiceQuantity] [numeric](25, 2) NOT NULL,
	[InvoiceQuantityinBaseUoM] [numeric](25, 2) NOT NULL,
	[InvoiceAmount] [numeric](25, 2) NULL,
	[InvoiceAmountinOperationalUSD] [numeric](25, 2) NULL,
	[NetQuantity] [numeric](25, 2) NOT NULL,
	[NetQuantityinBaseUoM] [numeric](25, 2) NOT NULL,
	[NetSales] [numeric](25, 2) NULL,
	[NetSalesinReportedUSD] [numeric](25, 2) NULL,
	[NetSalesinOperational] [numeric](25, 2) NULL,
	[ReturnQuantity] [numeric](25, 2) NOT NULL,
	[ReturnQuantityinBaseUoM] [numeric](25, 2) NOT NULL,
	[ReturnSales] [numeric](25, 2) NULL,
	[ReturnSalesinOperationalUSD] [numeric](25, 2) NULL,
	[ListPrice] [numeric](25, 2) NULL,
	[GrossQuantity] [numeric](25, 2) NOT NULL,
	[GrossQuantityinBaseUoM] [numeric](25, 2) NOT NULL,
	[GrossSales] [numeric](25, 2) NULL,
	[GrossSalesinReportedUSD] [numeric](25, 2) NULL,
	[GrossSalesinOperationalUSD] [numeric](25, 2) NULL,
	[LoadedDate] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


