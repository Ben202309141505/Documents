/****** Object:  Table [dbo].[fact_Account_Position]    Script Date: 6/16/2023 6:53:06 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fact_Account_Position]
(
	[dimCustomerKey] [int] NOT NULL,
	[dimTerritoryKey] [int] NOT NULL,
	[dimSalesRepresentativeKey] [int] NOT NULL,
	[dimMarketCodeKey] [int] NOT NULL,
	[dimTPfactAccountPositionKey] [int] NOT NULL,
	[AccountPositionID] [varchar](50) NOT NULL,
	[CallTarget] [decimal](38, 18) NOT NULL,
	[LoadedDate] [datetime] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


