/****** Object:  Table [dbo].[rpt_Species_Alloc_Aligned_Sls]    Script Date: 6/15/2023 8:41:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[rpt_Species_Alloc_Aligned_Sls]
(
	[MarketCode] [nvarchar](255) NULL,
	[SalesOrganizationID] [nvarchar](100) NULL,
	[SalesType] [nvarchar](255) NULL,
	[ProductID] [nvarchar](100) NULL,
	[CustomerID] [nvarchar](100) NULL,
	[BillToCustomerID] [nvarchar](100) NULL,
	[ShipToCustomerID] [nvarchar](255) NULL,
	[TransactionDate] [nvarchar](100) NULL,
	[TerritoryID] [nvarchar](100) NULL,
	[CurrencyCode] [nvarchar](100) NULL,
	[SpeciesCode] [nvarchar](255) NULL,
	[SpeciesSplitPercentage] [numeric](16, 9) NULL,
	[GrossSalesQuantity] [numeric](25, 7) NULL,
	[GrossSalesAmount] [numeric](25, 7) NULL,
	[ReturnsQuantity] [numeric](25, 7) NULL,
	[ReturnsAmount] [numeric](25, 7) NULL,
	[GrossLessReturnsQuantity] [numeric](25, 7) NULL,
	[GrossLessReturnsAmount] [numeric](25, 7) NULL,
	[InvoiceQuantity] [numeric](25, 7) NULL,
	[InvoiceAmount] [numeric](25, 7) NULL,
	[NetSalesQuantity] [numeric](25, 7) NULL,
	[NetSalesAmount] [numeric](25, 7) NULL,
	[CalculatedFinNetSalesAmount] [numeric](25, 7) NULL,
	[CalculatedInvoiceSalesAmount] [numeric](25, 7) NULL,
	[BillingDocumentNumber] [nvarchar](100) NULL,
	[BillingDocumentItemNumber] [nvarchar](100) NULL,
	[ProfitCenterID] [nvarchar](100) NULL,
	[SalesDocumentNumber] [nvarchar](100) NULL,
	[SalesDocumentItem] [nvarchar](100) NULL,
	[InvoiceTypeID] [nvarchar](100) NULL,
	[InvoiceTypeDescription] [nvarchar](255) NULL,
	[SalesDocumentType] [nvarchar](255) NULL,
	[SalesDocTypeDescription] [nvarchar](255) NULL,
	[UnitofMeasureID] [nvarchar](100) NULL,
	[TransactionPeriod] [nvarchar](255) NULL,
	[SalesDocumentItemCategoryID] [nvarchar](20) NULL,
	[ReportingCustomerNumber] [nvarchar](255) NULL,
	[ReportingSourceCustomerNumber] [nvarchar](255) NULL,
	[FinalSourceProductID] [nvarchar](255) NULL,
	[FlexibleAttr02] [nvarchar](100) NULL,
	[CustPrtZeroFlag] [nvarchar](10) NULL,
	[BusinessAreaID] [nvarchar](10) NULL,
	[FlexibleAttr01] [nvarchar](100) NULL,
	[WhlFgQuantity] [numeric](25, 7) NULL,
	[NS1] [numeric](25, 7) NULL,
	[VTJ3ExchangeUnits] [numeric](25, 7) NULL,
	[WHLReportedQuantity] [numeric](25, 7) NULL,
	[ProfPriceAmount] [numeric](25, 7) NULL,
	[FGProfPriceAmount] [numeric](25, 7) NULL,
	[NetPrice] [numeric](25, 7) NULL,
	[SalesDocumentItemCategory] [nvarchar](100) NULL,
	[SourceCustomerID] [nvarchar](255) NULL,
	[IndirectRebtateAmount] [numeric](38, 7) NULL,
	[FlexibleAttr04] [nvarchar](100) NULL,
	[FlexibleMeasure01] [numeric](25, 10) NULL,
	[SalesRepresentativeID] [bigint] NULL,
	[WorkdayID] [bigint] NULL,
	[CustomerProductSpeciesSplit] [numeric](16, 4) NULL,
	[CostElement] [nvarchar](100) NULL,
	[InsertDate] [nvarchar](100) NULL,
	[UpdateDate] [nvarchar](100) NULL,
	[JobRunKey] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionPeriod] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO


