/****** Object:  Table [dbo].[dim_Territory]    Script Date: 6/16/2023 6:43:31 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dim_Territory]
(
	[dim_Territory_Key] [bigint] NOT NULL,
	[CRM Territory Unique ID] [varchar](200) NOT NULL,
	[Territory ID] [varchar](400) NOT NULL,
	[Territory] [varchar](500) NOT NULL,
	[Territory Level] [varchar](500) NOT NULL,
	[Salesforce ID] [char](200) NOT NULL,
	[Salesforce] [varchar](500) NOT NULL,
	[Area ID] [char](200) NOT NULL,
	[Area] [varchar](500) NOT NULL,
	[Region ID] [char](200) NOT NULL,
	[Region] [varchar](500) NOT NULL,
	[Division ID] [varchar](100) NOT NULL,
	[Division] [varchar](250) NOT NULL,
	[Species ID] [varchar](100) NOT NULL,
	[Species] [varchar](160) NOT NULL,
	[Territory Effective Start Date] [date] NOT NULL,
	[Territory Effective End date] [date] NOT NULL,
	[Market Code] [varchar](110) NOT NULL,
	[Market Name] [varchar](380) NOT NULL,
	[Business Unit] [varchar](100) NOT NULL,
	[Level 1 ID] [varchar](500) NOT NULL,
	[Level 1 Name] [varchar](300) NOT NULL,
	[Level 2 ID] [varchar](500) NOT NULL,
	[Level 2 Name] [varchar](300) NOT NULL,
	[Level 3 ID] [varchar](500) NOT NULL,
	[Level 3 Name] [varchar](300) NOT NULL,
	[Level 4 ID] [varchar](500) NOT NULL,
	[Level 4 Name] [varchar](300) NOT NULL,
	[Level 5 ID] [varchar](500) NOT NULL,
	[Level 5 Name] [varchar](300) NOT NULL,
	[Level 6 ID] [varchar](500) NOT NULL,
	[Level 6 Name] [varchar](300) NOT NULL,
	[Territory Status] [varchar](150) NOT NULL,
	[Source System] [varchar](280) NOT NULL,
	[IsAssigned] [varchar](280) NOT NULL,
	[Is Active] [varchar](280) NOT NULL,
	[Is Deleted] [varchar](280) NOT NULL,
	[Current Row] [varchar](10) NOT NULL,
	[Row Effective From] [datetime2](7) NULL,
	[Row Effective To] [datetime2](7) NULL,
	[Insert_Date] [datetime2](7) NULL,
	[Update_Date] [datetime2](7) NULL,
	[Job_Run_Key] [bigint] NULL,
	[SubLevel5Name] [varchar](500) NOT NULL,
	[SubLevel5ID] [varchar](500) NOT NULL,
	[SubLevel4Name] [varchar](50) NOT NULL,
	[SubLevel4ID] [varchar](500) NOT NULL,
	[AMID] [varchar](500) NOT NULL,
	[ABMID] [varchar](500) NOT NULL,
	[BUDID] [varchar](500) NOT NULL,
	[GMID] [varchar](500) NOT NULL,
	[CountryID] [varchar](500) NOT NULL,
	[HOSID] [varchar](500) NOT NULL,
	[DCDMID] [varchar](500) NOT NULL
)
WITH
(
	DISTRIBUTION = HASH ( [CRM Territory Unique ID] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO


