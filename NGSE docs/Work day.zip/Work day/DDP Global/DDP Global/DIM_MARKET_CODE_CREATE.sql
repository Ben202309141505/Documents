/****** Object:  Table [dbo].[dim_Market_Code]    Script Date: 6/16/2023 6:49:00 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dim_Market_Code]
(
	[dimMarketCodeKey] [int] NOT NULL,
	[MarketCode] [nvarchar](10) NOT NULL,
	[Market] [nvarchar](25) NOT NULL,
	[InsertDate] [datetime2](7) NULL,
	[UpdateDate] [datetime2](7) NULL,
	[JobRunID] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


