/****** Object:  Table [dbo].[fact_Indirect_Sales]    Script Date: 6/16/2023 7:12:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[fact_Indirect_Sales]
(
	[dim_Date_Key] [int] NOT NULL,
	[dim_Date_Month_Key] [int] NOT NULL,
	[dim_Source_Product_Key] [int] NOT NULL,
	[dim_Product_Key] [int] NOT NULL,
	[dim_Source_Customer_Key] [int] NOT NULL,
	[dim_Source_Bill_to_Customer_Key] [int] NOT NULL,
	[dim_Source_Ship_to_Customer_Key] [int] NOT NULL,
	[dim_Customer_Key] [int] NOT NULL,
	[dim_Bill_to_Customer_Key] [int] NOT NULL,
	[dim_Ship_to_Customer_Key] [int] NOT NULL,
	[dim_MarketCode_Key] [smallint] NOT NULL,
	[dim_Sales_Organization_Key] [smallint] NOT NULL,
	[dim_Currency_Key] [smallint] NOT NULL,
	[FlexibleAttr01] [varchar](200) NOT NULL,
	[FlexibleAttr02] [varchar](200) NOT NULL,
	[FlexibleAttr03] [varchar](200) NOT NULL,
	[FlexibleAttr04] [varchar](200) NOT NULL,
	[FlexibleAttr05] [varchar](200) NOT NULL,
	[PostingCode] [varchar](300) NOT NULL,
	[GrossSalesQuantity] [decimal](38, 12) NULL,
	[GrossSalesAmount] [decimal](36, 16) NULL,
	[ReturnsQuantity] [decimal](28, 10) NULL,
	[ReturnsAmount] [decimal](28, 10) NULL,
	[GrossLessReturnsQuantity] [decimal](30, 10) NULL,
	[GrossLessReturnsAmount] [decimal](30, 10) NULL,
	[NetSalesQuantity] [decimal](38, 12) NULL,
	[NetSalesAmount] [decimal](28, 10) NULL,
	[ListPriceAmount] [decimal](28, 10) NULL,
	[AvgInvoicePriceAmount] [decimal](28, 10) NULL,
	[WholesalePriceAmount] [decimal](28, 10) NULL,
	[CustomPriceAmount] [decimal](28, 10) NULL,
	[PurchasePriceAmount] [decimal](28, 10) NULL,
	[InvoiceQuantity] [decimal](30, 10) NULL,
	[InvoiceAmount] [decimal](30, 10) NULL,
	[FlexibleMeasure01] [decimal](38, 12) NULL,
	[FlexibleMeasure02] [decimal](38, 12) NULL,
	[FlexibleMeasure03] [decimal](38, 12) NULL,
	[FlexibleMeasure04] [decimal](38, 12) NULL,
	[FlexibleMeasure05] [decimal](38, 12) NULL,
	[FlexibleMeasure06] [decimal](38, 12) NULL,
	[FlexibleMeasure07] [decimal](38, 12) NULL,
	[FlexibleMeasure08] [decimal](38, 12) NULL,
	[FlexibleMeasure09] [decimal](38, 12) NULL,
	[FlexibleMeasure10] [decimal](38, 12) NULL,
	[FlexibleMeasure11] [decimal](28, 10) NULL,
	[FlexibleMeasure12] [decimal](28, 10) NULL,
	[FlexibleMeasure13] [int] NULL,
	[FlexibleMeasure14] [decimal](28, 10) NULL,
	[FlexibleMeasure15] [decimal](28, 10) NULL,
	[Insert_Date] [datetime2](7) NULL,
	[Update_Date] [datetime2](7) NULL,
	[Job_Run_Key] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [dim_Source_Ship_to_Customer_Key] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO


