/****** Object:  Table [dbo].[rpt_Species_Alloc_Sls]    Script Date: 6/16/2023 7:13:56 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[rpt_Species_Alloc_Sls]
(
	[TransactionDate] [varchar](20) NULL,
	[TransactionPeriod] [varchar](20) NULL,
	[ProductID] [nvarchar](300) NULL,
	[CustomerID] [nvarchar](300) NULL,
	[SourceCustomerID] [nvarchar](300) NULL,
	[BillToCustomerID] [nvarchar](300) NULL,
	[SourceBillToCustomerID] [nvarchar](300) NULL,
	[ShipToCustomerID] [nvarchar](300) NULL,
	[SourceShipToCustomerID] [nvarchar](300) NULL,
	[MarketCode] [nvarchar](20) NULL,
	[BillingDocumentNumber] [nvarchar](40) NULL,
	[BillingDocumentItemNumber] [nvarchar](10) NULL,
	[ReportingCustomerNumber] [nvarchar](300) NULL,
	[ReportingSourceCustomerNumber] [nvarchar](300) NULL,
	[FinalSourceProductID] [nvarchar](300) NULL,
	[SalesDocumentNumber] [nvarchar](10) NULL,
	[SalesDocumentItem] [nvarchar](100) NULL,
	[InvoiceTypeID] [nvarchar](100) NULL,
	[InvoiceTypeDescription] [nvarchar](50) NULL,
	[SalesDocumentType] [nvarchar](10) NULL,
	[SalesDocTypeDescription] [nvarchar](50) NULL,
	[ProfitCenterID] [nvarchar](25) NULL,
	[UnitofMeasureID] [nvarchar](100) NULL,
	[SalesOrganizationID] [nvarchar](300) NULL,
	[SalesRepresentativeID] [nvarchar](100) NULL,
	[WorkdayID] [nvarchar](50) NULL,
	[BusinessAreaID] [nvarchar](10) NULL,
	[SalesDocumentItemCategoryID] [nvarchar](10) NULL,
	[CurrencyCode] [nvarchar](20) NULL,
	[SalesType] [nvarchar](255) NULL,
	[SpeciesCode] [nvarchar](20) NULL,
	[SpeciesSplitPercentage] [numeric](38, 9) NULL,
	[GrossSalesQuantity] [numeric](38, 12) NULL,
	[GrossSalesAmount] [numeric](38, 16) NULL,
	[ReturnsQuantity] [nvarchar](50) NULL,
	[ReturnsAmount] [nvarchar](50) NULL,
	[GrossLessReturnsQuantity] [nvarchar](50) NULL,
	[GrossLessReturnsAmount] [nvarchar](50) NULL,
	[InvoiceQuantity] [numeric](38, 7) NULL,
	[InvoiceAmount] [numeric](38, 7) NULL,
	[NetSalesQuantity] [numeric](38, 12) NULL,
	[NetSalesAmount] [numeric](28, 10) NULL,
	[CalculatedFinNetSalesAmount] [nvarchar](50) NULL,
	[CalculatedInvoiceSalesAmount] [nvarchar](50) NULL,
	[FlexibleAttr01] [nvarchar](200) NULL,
	[FlexibleAttr02] [nvarchar](200) NULL,
	[FlexibleAttr03] [nvarchar](200) NULL,
	[FlexibleAttr04] [nvarchar](200) NULL,
	[FlexibleAttr05] [nvarchar](200) NULL,
	[FlexibleMeasure01] [decimal](38, 12) NULL,
	[FlexibleMeasure02] [decimal](38, 12) NULL,
	[FlexibleMeasure03] [decimal](38, 12) NULL,
	[FlexibleMeasure04] [decimal](38, 12) NULL,
	[FlexibleMeasure05] [decimal](38, 12) NULL,
	[CustomerPrtFlag] [nvarchar](100) NULL,
	[NS1] [numeric](38, 7) NULL,
	[VTJ3ExchangeUnits] [numeric](38, 7) NULL,
	[WHLReportedQuantity] [numeric](38, 7) NULL,
	[ProfPriceAmount] [numeric](38, 7) NULL,
	[FGProfPriceAmount] [numeric](38, 7) NULL,
	[WholeFgQuantity] [numeric](38, 7) NULL,
	[NetPrice] [numeric](38, 7) NULL,
	[SalesDocumentItemCategory] [nvarchar](100) NULL,
	[IndirectRebateAmount] [decimal](17, 2) NULL,
	[CostElement] [nvarchar](50) NULL,
	[PostingDate] [nvarchar](50) NULL,
	[AccountID] [nvarchar](50) NULL,
	[Insert_Date] [datetime2](7) NULL,
	[Update_Date] [datetime2](7) NULL,
	[Job_Run_Key] [bigint] NULL
)
WITH
(
	DISTRIBUTION = HASH ( [TransactionPeriod] ),
	CLUSTERED COLUMNSTORE INDEX
)
GO


