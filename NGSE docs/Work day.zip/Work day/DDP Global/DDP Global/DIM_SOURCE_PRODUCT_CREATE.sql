/****** Object:  Table [dbo].[dim_Source_Product]    Script Date: 6/16/2023 6:42:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dim_Source_Product]
(
	[SourceProductKey] [int] NOT NULL,
	[MarketCode] [varchar](10) NOT NULL,
	[SourceProductID] [varchar](100) NOT NULL,
	[MasterProductID] [varchar](45) NOT NULL,
	[SourceSystem] [varchar](15) NOT NULL,
	[CRMProductID] [varchar](20) NOT NULL,
	[CRMProduct] [nvarchar](100) NOT NULL,
	[LevelID] [varchar](10) NOT NULL,
	[SourceProductLevel4ID] [varchar](50) NOT NULL,
	[SourceProductLevel4] [varchar](100) NOT NULL,
	[CRMProductLevel4ID] [varchar](50) NOT NULL,
	[CRMProductLevel4] [nvarchar](100) NOT NULL,
	[Level4ID] [varchar](10) NOT NULL,
	[SourceProductLevel3ID] [varchar](50) NOT NULL,
	[SourceProductLevel3] [varchar](100) NOT NULL,
	[CRMProductLevel3ID] [varchar](50) NOT NULL,
	[CRMProductLevel3] [nvarchar](100) NOT NULL,
	[Level3ID] [varchar](10) NOT NULL,
	[SourceProductLevel2ID] [varchar](50) NOT NULL,
	[SourceProductLevel2] [varchar](100) NOT NULL,
	[CRMProductLevel2ID] [varchar](50) NOT NULL,
	[CRMProductLevel2] [nvarchar](100) NOT NULL,
	[Level2ID] [varchar](10) NOT NULL,
	[SourceProductLevel1ID] [varchar](50) NOT NULL,
	[SourceProductLevel1] [varchar](100) NOT NULL,
	[CRMProductLevel1ID] [varchar](50) NOT NULL,
	[CRMProductLevel1] [nvarchar](100) NOT NULL,
	[Level1ID] [varchar](10) NOT NULL,
	[ExchangeRate] [decimal](13, 5) NOT NULL,
	[InsertDate] [datetime2](7) NULL,
	[UpdateDate] [datetime2](7) NULL,
	[JobRunID] [bigint] NULL
)
WITH
(
	DISTRIBUTION = REPLICATE,
	CLUSTERED COLUMNSTORE INDEX
)
GO


