/****** Object:  Table [dbo].[dim_Sales_Representative]    Script Date: 6/16/2023 6:47:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[dim_Sales_Representative]
(
	[dim_Sales_Representative_Key] [int] NOT NULL,
	[Sales Representative ID] [varchar](60) NOT NULL,
	[Sales Representative] [nvarchar](60) NOT NULL,
	[Market Code] [varchar](11) NOT NULL,
	[Market Name] [varchar](25) NOT NULL,
	[First Name] [nvarchar](50) NOT NULL,
	[Last Name] [nvarchar](50) NOT NULL,
	[Email] [varchar](60) NOT NULL,
	[LAN ID] [varchar](25) NOT NULL,
	[Title] [nvarchar](150) NOT NULL,
	[Manager ID] [varchar](50) NOT NULL,
	[Workday ID] [int] NOT NULL,
	[Primary BU] [varchar](50) NOT NULL,
	[Last Login Date] [datetime2](7) NULL,
	[Role Name] [varchar](60) NOT NULL,
	[Profile Number] [varchar](50) NOT NULL,
	[Profile Name] [varchar](60) NOT NULL,
	[Type] [varchar](60) NULL,
	[Is Active] [varchar](20) NOT NULL,
	[Payee ID] [int] NOT NULL,
	[Payee Name] [varchar](50) NOT NULL,
	[Manager Employee ID] [int] NOT NULL,
	[Manager Name] [nvarchar](120) NOT NULL,
	[Insert_Date] [datetime2](7) NULL,
	[Update_Date] [datetime2](7) NULL,
	[Job_Run_Key] [bigint] NULL
)
WITH
(
	DISTRIBUTION = ROUND_ROBIN,
	CLUSTERED COLUMNSTORE INDEX
)
GO


